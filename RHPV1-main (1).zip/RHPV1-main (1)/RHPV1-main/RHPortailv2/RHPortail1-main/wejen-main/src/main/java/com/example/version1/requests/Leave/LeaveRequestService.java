package com.example.version1.requests.Leave;

import com.example.version1.requests.Leave.LeaveRequest;
import com.example.version1.requests.Leave.LeaveRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeaveRequestService {

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;

    public LeaveRequest createLeaveRequest(LeaveRequest request , Long userId) {
        return leaveRequestRepository.save(request);
    }
    public List<LeaveRequest> getAllLeaveRequests() {
        return leaveRequestRepository.findAll();
    }
    public List<LeaveRequest> getPendingLeaveRequests() {
        return leaveRequestRepository.findByStatus("pending");
    }

    public LeaveRequest updateLeaveRequestStatusAndResponse(Long id, String newStatus, String response) {
        LeaveRequest request = leaveRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Leave request not found with ID: " + id));

        request.setStatus(newStatus);
        request.setResponse(response);

        return leaveRequestRepository.save(request);
    }

    public int countPendingLeaveRequests() {
        return leaveRequestRepository.countByStatus("pending");

    }
}
