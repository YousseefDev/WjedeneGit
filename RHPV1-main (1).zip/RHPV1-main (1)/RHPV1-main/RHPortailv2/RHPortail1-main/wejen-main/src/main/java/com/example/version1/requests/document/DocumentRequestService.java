package com.example.version1.requests.document;

import com.example.version1.requests.document.DocumentRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DocumentRequestService {

    private final DocumentRequestRepository documentRequestRepository;

    @Autowired
    public DocumentRequestService(DocumentRequestRepository documentRequestRepository) {
        this.documentRequestRepository = documentRequestRepository;
    }

    public DocumentRequest createDocumentRequest(DocumentRequest documentRequest, Long userId) {
        // Set user ID on the document request before saving
        documentRequest.setUserId(userId);
        return documentRequestRepository.save(documentRequest);
    }
    public List<DocumentRequest> getAllDocumentRequests() {
        return documentRequestRepository.findAll();
    }
    public List<DocumentRequest> getPendingDocumentRequests() {
        return documentRequestRepository.findByStatus("pending");
    }

    public DocumentRequest updateDocumentRequestStatusAndResponse(Long id, String newStatus, String response) {
        DocumentRequest request = documentRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Document request not found with ID: " + id));

        request.setStatus(newStatus);
        request.setResponse(response);

        return documentRequestRepository.save(request);
    }
    public int countPendingDocumentRequests() {
        return documentRequestRepository.countByStatus("pending");
    }
}
