import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-user-requests',
  templateUrl: './user-requests.component.html',
  styleUrls: ['./user-requests.component.scss']
})
export class UserRequestsComponent implements OnInit {
  requests: any[] = [];

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.loadUserRequests();
  }

  loadUserRequests(): void {
    this.apiService.getMyRequests().subscribe(
      (requests: any[]) => {
        this.requests = requests;
      },
      error => {
        console.error('Error fetching user requests:', error);
      }
    );
  }

  isLoanRequest(request: any): boolean {
    return request.title && request.description && request.amount && request.purpose && request.repaymentPlan && request.loanType;
  }

  isPersonalSituationRequest(request: any): boolean {
    return request.requestType && !request.title && !request.description && !request.documentType && !request.type;
  }

  isDocumentRequest(request: any): boolean {
    return request.documentType && !request.requestType && !request.title && !request.description && !request.type;
  }

  isOtherRequest(request: any): boolean {
    return !this.isLoanRequest(request) && !this.isPersonalSituationRequest(request) && !this.isDocumentRequest(request);
  }
}
